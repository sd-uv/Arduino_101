# ardBatteryTester
Battery tester ardunio scratch
Requirement
. Arduino Uno or Mega2560
. LCD Keypad shiled
. Wire
